import React from 'react';
const Myall = () =>{
    return(
        <div className="container text-center">
            <div className='row'>
                <div className='col-lg-12'>
                    <h3 className='text-primary'> All Data From Redux Store </h3>
                </div>
            </div>
        </div>
    )
}
export default Myall;