
const Booklist = (state=[], action) =>{
    const oldandnewbook = Object.assign([], state); // to captute old value from state
    
    return oldandnewbook;
}

export default Booklist;