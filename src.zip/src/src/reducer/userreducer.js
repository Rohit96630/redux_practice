const Userlist = (state=[], action) =>{
    const oldandnewuser = Object.assign([], state); // to captute old value from state
    
    return oldandnewuser;
}

export default Userlist;